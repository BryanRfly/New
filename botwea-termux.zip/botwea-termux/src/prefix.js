const cekprefix = (prefix) => { 
	return `
	PREFIX YANG SAAT INI DIGUNAKAN *「* ${prefix} *」
	`
	}
exports.cekprefix = cekprefix