const animemenu = (prefix) => { 
	return `
╔══✪〘 ANIME 〙✪══
║
╠➥ *${prefix}randomanime*
╠➥ *${prefix}waifu*
╠➥ *${prefix}waifu2*
╠➥ *${prefix}nekonime*
╠➥ *${prefix}genreanime*
╠➥ *${prefix}animesaran*
╠➥ *${prefix}animesaran2*
╠➥ *${prefix}wibu*
╠➥ *${prefix}wait [foto opening anime]*
╠➥ *${prefix}inu*
╠➥ *${prefix}pokemon*
╠➥ *${prefix}naruto*
╠➥ *${prefix}ranime*
╠➥ *${prefix}hinata*
╠➥ *${prefix}sasuke*
╠➥ *${prefix}sakura*
╠➥ *${prefix}boruto*
╠➥ *${prefix}minato*
╠➥ *${prefix}loli*
╠➥ *${prefix}loli2*
╠➥ *${prefix}rize*
╠➥ *${prefix}akira*
╠➥ *${prefix}husbu*
╠➥ *${prefix}itori*
╠➥ *${prefix}animesad*
╠➥ *${prefix}animehappy* 
╠➥ *${prefix}kurumi*
╠➥ *${prefix}miku*
║
╚═〘 BRYAN BOT 〙`
}
exports.animemenu = animemenu