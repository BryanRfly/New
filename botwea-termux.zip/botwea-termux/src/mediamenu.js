const mediamenu = (prefix) => { 
	return `

╔══✪〘 MEDIA 〙✪══
║
╠➥ *${prefix}yt* [link]
╠➥ *${prefix}tiktok* [link]
╠➥ *${prefix}ytsearch* [yt search]
╠➥ *${prefix}lirik* [judul lagu]
╠➥ *${prefix}chord* [judul lagu]
╠➥ *${prefix}igstalk* [Rizky]
╠➥ *${prefix}fb [url]*
╠➥ *${prefix}wikien* [love]
╠➥ *${prefix}tiktokstalk* [username]
╠➥ *${prefix}img2url* [reply foto]
╠➥ *${prefix}trendtwit*
╠➥ *${prefix}fototiktok* [username]
╠➥ *${prefix}map* [kota]
╠➥ *${prefix}kbbi* [kamus]
╠➥ *${prefix}brainly* [tau sendiri kan]
╠➥ *${prefix}infoghitub* 
╠➥ *${prefix}neonime
╠➥ *${prefix}cuaca* [kota]
╠➥ *${prefix}infogempa*
╠➥ *${prefix}artinama [nama]*
╠➥ *${prefix}spamcall [82387804410]*
╠➥ *${prefix}covid [negara]*
╠➥ *${prefix}nulis [teks]*
╠➥ *${prefix}sandwriting [teks]*
╠➥ *${prefix}quotemaker [|teks|author|theme]*
╠➥ *${prefix}resepmasakan [optional]*
╠➥ *${prefix}tts [kode bhs] [teks]*
╠➥ *${prefix}igstalk [@username]*
╠➥ *${prefix}tiktokstalk [@username]*
╠➥ *${prefix}darkjokes*
╠➥ *${prefix}wiki [query]*
╠➥ *${prefix}infonomor [823×××]*
╠➥ *${prefix}slap*
╠➥ *${prefix}xd*
╠➥ *${prefix}aguse*
╠➥ *${prefix}infomobil [namamobil]*
╠➥ *${prefix}infomotor [namamotor]*
╠➥ *${prefix} playstore [nama game]*
╠➥ *${prefix}beritahoax*
╠➥ *${prefix}ramalhp [823×××]*
╠➥ *${prefix}qrcode [optional]*
╠➥ *${prefix}map [optional]*
╠➥ *${prefix}textmaker [teks1|teks2]*
╠➥ *${prefix}ssweb [linkWeb]*
╠➥ *${prefix}shorturl [linkWeb]*
╠➥ *${prefix}quran*
║
╚═〘 BRYAN BOT 〙`
}
exports.mediamenu = mediamenu