const ownermenu = (prefix) => { 
	return `
	
╔══✪〘 OWNER 〙✪══
║
╠➥ *${prefix}block 62858xxxxx*
╠➥ *${prefix}unblock 62858xxxxx*
╠➥ *${prefix}promote @tagmember*
╠➥ *${prefix}demote @tagadmin*
╠➥ *${prefix}bc*
╠➥ *${prefix}leave*
╠➥  *${prefix}bc2*
╠➥  *${prefix}leave*
╠➥  *${prefix}clearall*
╠➥  *${prefix}clone*
╠➥  *${prefix}hidetag*
╠➥  *${prefix}hidetag2*
╠➥  *${prefix}setprefix*
╠➥  *${prefix}unban*
╠➥  *${prefix}ban*
╠➥ *${prefix}runtime*
╠➥ *${prefix}hidetag5*
╠➥ *${prefix}hidetag50*
╠➥ *${prefix}hidetag20*
╠➥ *${prefix}hidetag300*
╠➥ *${prefix}getppbot*
╠➥ *${prefix}bcgc*
╠➥ *${prefix}turnoff*
╠➥  *${prefix}getses*
╠➥  *${prefix}addfoto [reply foto]*
╠➥  *${prefix}getfoto [nama file]*
╠➥  *${prefix}addaudio [reply audio]*
╠➥  *${prefix}getaudio [nama file]*
╠➥  *${prefix}addvideo ,[reply video]*
╠➥  *${prefix}getvideo [nama file]*
╠➥ *${prefix}resetsay*
╠➥ *${prefix}addsay*
╠➥ *${prefix}saylist*
╠➥ *${prefix}addbacot*
╠➥ *${prefix}bacotlist*
╠➥ *${prefix}resetbacot*
╠➥ *${prefix}resetuser*
╠➥ *${prefix}addvip [nomor@s.whatsapp.net]*
╠➥ *${prefix}resetallvipuser*
╠➥  *${prefix}getsticker [teks]*
╠➥  *${prefix}savestick [nama file]*
╠➥  *${prefix}
╠➥ *${prefix}totaluser*
║
╚═〘 BRYAN BOT 〙`
}
exports.ownermenu = ownermenu